import TaskForm from "./TaskForm";
import { useEffect, useState } from "react";
// import VolunteerForm from "./VolunteerForm"; // The form component you'll create
const AddTaskTab = ({
  selectedVolunteering,
  callBack,
  cancel,
  hide,
  selectedVolunteeringHide,
  ref,
  whenVisible,
}) => {
  const [fadeIn, setFadeIn] = useState(false);
  const [show, setShow] = useState(false);
  const [data, setData] = useState({});
  useEffect(() => {
    if (selectedVolunteering) {
      setData({
        ...selectedVolunteering,
      });
      setShow(true);
      setFadeIn(true);
    } else {
      setFadeIn(false);
      setTimeout(() => {
        setShow(false);
      }, 500);
    }
  }, [selectedVolunteering]);
  return (
    <>
      {show && (
        <div
          className={`${fadeIn ? " animate-slide-up" : "fadeOut"}`}
          ref={ref}
        >
          <div className="mt-4">
            {!selectedVolunteeringHide && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <div className="flex items-center justify-between mb-3 border-b border-blue-900 pb-4">
                  <h3 className="text-lg font-medium text-blue-900">
                    Selected Volunteering
                  </h3>
                  <button
                    onClick={cancel}
                    className="text-blue-600 hover:text-blue-800 text-sm font-medium underline"
                  >
                    Cancel
                  </button>
                </div>

                <div className={"grid grid-cols-1" + !hide && "md:grid-cols-2"}>
                  {!hide && (
                    <div className="mb-4">
                      <h3 className="text-md font-medium text-blue-900 mb-2 ">
                        Volunteer Info:
                      </h3>

                      <div className="grid grid-cols-1 gap-1">
                        <div>
                          <div>
                            <span className="text-sm text-blue-900 font-medium">
                              Name:
                            </span>
                            <span className="ml-2 text-blue-900">
                              {`${data?.firstName || "N/A"} ${
                                data?.lastName || "N/A"
                              }`}
                            </span>
                          </div>
                        </div>

                        <div>
                          <span className="text-sm text-blue-900  font-medium">
                            Email:
                          </span>
                          <span className="ml-2 text-blue-900">
                            {data?.email || "N/A"}
                          </span>
                        </div>
                        <div>
                          <span className="text-sm text-blue-900  font-medium">
                            Phone:
                          </span>
                          <span className="ml-2 text-blue-900">
                            {data?.phone || "N/A"}
                          </span>
                        </div>
                      </div>
                    </div>
                  )}

                  <div className="mb-4">
                    <h3 className="text-md font-medium text-blue-900 mb-2 ">
                      Volunteering Info:
                    </h3>
                    <div className="grid grid-cols-1 gap-1">
                      <div>
                        <div className="">
                          <span className="text-sm text-blue-900 font-medium">
                            Title:
                          </span>
                          <span className="ml-2 text-blue-900">
                            {data?.volunteerTitle || "N/A"}
                          </span>
                        </div>
                      </div>

                      <div>
                        <span className="text-sm text-blue-900  font-medium">
                          Type:
                        </span>
                        <span className="ml-2 text-blue-900">
                          {data?.roleTitle || "N/A"}
                          someData
                        </span>
                      </div>
                      <div>
                        <span className="text-sm text-blue-900  font-medium">
                          Start Date:
                        </span>
                        <span className="ml-2 text-blue-900">
                          {new Date(data?.startDate).toLocaleDateString() ||
                            "N/A"}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="mb-4">
                  <h3 className="text-md font-medium text-blue-900 mb-2 w-full">
                    Description:
                  </h3>
                  <div className="grid grid-cols-1 gap-1">
                    <div>
                      <div className="">
                        <span className="ml-2 text-blue-900">
                          {data?.description || "N/A"}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            <div className="mt-5">
              <TaskForm teamVolunteerId={data?.id} callBack={callBack} />
              {whenVisible ? whenVisible() : ""}
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default AddTaskTab;
