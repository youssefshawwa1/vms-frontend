// const API = "http://localhost/vms/backend/api/";
const API = "https://fekra.somewebsite.store/api/api/";
const LoadingTime = 50;
const MessageTime = 4000;
export { API, LoadingTime, MessageTime };
